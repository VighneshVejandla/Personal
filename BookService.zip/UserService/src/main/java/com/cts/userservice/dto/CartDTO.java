package com.cts.userservice.dto;

import lombok.Data;

import java.util.List;

@Data
public class CartDTO {
	private Integer cartId;
    private Integer userId;
    private List<CartItemDTO> cartItems;
    private double totalPrice;
}
