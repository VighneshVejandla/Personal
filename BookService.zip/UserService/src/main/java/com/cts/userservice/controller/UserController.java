package com.cts.userservice.controller;

import java.util.List;

import com.cts.userservice.dto.*;
import com.cts.userservice.entity.User;
import com.cts.userservice.feignclient.CartFeignClient;
import com.cts.userservice.feignclient.PaymentFeignClient;
import com.cts.userservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.cts.userservice.service.IUserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/user")
@CrossOrigin("*")
public class UserController {

	@Autowired
	IUserService userService;

	@Autowired
	UserRepository userRepository;

	@Autowired
	CartFeignClient cartFeignClient;

	@Autowired
	PaymentFeignClient paymentFeignClient;

	@PostMapping("/adduser")
	public ResponseEntity<UserDto> addUser(@RequestBody UserDto userDto) {
		return new ResponseEntity<UserDto>(userService.addUser(userDto), HttpStatus.OK);
	}

	@GetMapping("/viewallusers")
	public ResponseEntity<List<UserDto>> viewAllUsers() {
		return new ResponseEntity<List<UserDto>>(userService.viewAllUsers(), HttpStatus.OK);
	}

	@GetMapping("/viewuserbyid/{userId}")
	public ResponseEntity<UserDto> viewUserById(@PathVariable Long userId) {
		return new ResponseEntity<UserDto>(userService.getUserById(userId), HttpStatus.OK);
	}

	@PutMapping("/updateuser/{userId}")
	public ResponseEntity<UserDto> updateUserById(@PathVariable Long userId, @RequestBody UserDto user) {
		return new ResponseEntity<UserDto>(userService.updateUserById(userId, user), HttpStatus.OK);
	}

	@DeleteMapping("/deleteuser/{userId}")
	public ResponseEntity<String> deleteUserById(@PathVariable Long userId) {
		userService.deleteUserById(userId);
		return new ResponseEntity<String>("User deleted successfully", HttpStatus.OK);
	}

	@DeleteMapping("/deleteusertotally/{userId}")
	public ResponseEntity<String> deleteUserByIdPermenent(@PathVariable Long userId) {
		userService.deleteUserByIdPermenent(userId);
		return new ResponseEntity<String>("User deleted successfully from the database", HttpStatus.OK);
	}

	@PutMapping("/recoveraccountbyemail/{email}")
	public ResponseEntity<String> recoverTheAccountByEmail(@PathVariable String email) {
		userService.recoverTheAccountByEmail(email);
		return new ResponseEntity<String>("Account Recovered Successfully", HttpStatus.OK);
	}

	@PutMapping("/recoveraccountbyuserid/{userId}")
	public ResponseEntity<String> recoverTheAccountByUserId(@PathVariable Long userId) {
		userService.recoverTheAccountByUserId(userId);
		return new ResponseEntity<String>("Account Recovered Successfully", HttpStatus.OK);
	}

	@PutMapping("/changepassword/{userId}")
	public ResponseEntity<String> changePassword(@Valid @PathVariable Long userId, @RequestBody PasswordDto password) {
		userService.changePassword(userId, password);
		return new ResponseEntity<String>("Password Changed Successfully", HttpStatus.OK);
	}

	@GetMapping("/getalldeletedusers")
	public ResponseEntity<List<User>>  getAllDeletedUsers(){
		return new ResponseEntity<List<User>>(userService.getAllDeletedUsers(), HttpStatus.OK);
	}

//	---------------Cart Feign Clients------------

	@GetMapping("/viewcartitems/{userId}")
	public ResponseEntity<List<CartItemDTO>> viewCartItems(@PathVariable Long userId){
		List<CartItemDTO> cartItems = cartFeignClient.getCartItems(userId);
		return new ResponseEntity<>(cartItems, HttpStatus.OK);
	}

	@PostMapping("/{userId}/add-to-cart")
	public ResponseEntity<CartDTO> addToCart(@PathVariable Long userId, @RequestBody CartItemDTO item) {
		return new ResponseEntity<>(cartFeignClient.addToCart(userId, item), HttpStatus.OK);
	}

	@PutMapping("/{userId}/increase-quantity/{productId}")
	public ResponseEntity<CartDTO> increaseQuantity(@PathVariable Long userId,
													@PathVariable Long productId,
													@RequestParam int quantity) {
		return new ResponseEntity<>(cartFeignClient.increaseQuantity(userId, productId, quantity), HttpStatus.OK);
	}

	@PutMapping("/{userId}/decrease-quantity/{productId}")
	public ResponseEntity<CartDTO> decreaseQuantity(@PathVariable Long userId,
													@PathVariable Long productId,
													@RequestParam int quantity) {
		return new ResponseEntity<>(cartFeignClient.decreaseQuantity(userId, productId, quantity), HttpStatus.OK);
	}

	@DeleteMapping("/{userId}/remove-from-cart/{productId}")
	public ResponseEntity<String> removeFromCart(@PathVariable Long userId, @PathVariable Long productId) {
		return new ResponseEntity<>(cartFeignClient.removeFromCart(userId, productId), HttpStatus.OK);
	}

	@DeleteMapping("/{userId}/clear-cart")
	public ResponseEntity<String> clearCart(@PathVariable Long userId) {
		return new ResponseEntity<>(cartFeignClient.clearCart(userId), HttpStatus.OK);
	}

	@GetMapping("/{userId}/cart-total")
	public ResponseEntity<Double> getTotalCartValue(@PathVariable Long userId) {
		return new ResponseEntity<>(cartFeignClient.getTotalPrice(userId), HttpStatus.OK);
	}



//	-------------Payment Feign Client----------------------

	@PostMapping("/make-payment")
	public ResponseEntity<PaymentResponseDto> initiatePayment(@RequestBody PaymentRequestDto paymentDto) {
		PaymentResponseDto response = paymentFeignClient.initiatePayment(paymentDto);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PutMapping("/confirm-payment/{paymentId}")
	public ResponseEntity<String> confirmPayment(@PathVariable Long paymentId) {
		String status = paymentFeignClient.updatePaymentStatus(paymentId);
		return new ResponseEntity<>(status, HttpStatus.OK);
	}

	@GetMapping("/view-payment/{paymentId}")
	public ResponseEntity<String> viewPayment(@PathVariable Long paymentId) {
		return new ResponseEntity<>(paymentFeignClient.viewPaymentStatus(paymentId), HttpStatus.OK);
	}

	@PutMapping("/cancel-payment/{paymentId}")
	public ResponseEntity<String> cancelPayment(@PathVariable Long paymentId) {
		return paymentFeignClient.cancelPayment(paymentId);
	}





}
