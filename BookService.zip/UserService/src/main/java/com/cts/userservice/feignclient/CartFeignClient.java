package com.cts.userservice.feignclient;

import com.cts.userservice.dto.CartDTO;
import com.cts.userservice.dto.CartItemDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "CartModule", path = "/api/v1/cart")
public interface CartFeignClient {

    @PostMapping("/{userId}/createcart")
    String createCart(@PathVariable Long userId);

    @PostMapping("/{userId}/addproduct")
    CartDTO addToCart(@PathVariable("userId") Long userId, @RequestBody CartItemDTO cartItemDTO);

    @DeleteMapping("/{userId}/removeproduct/{productId}")
    String removeFromCart(@PathVariable("userId") Long userId, @PathVariable("productId") Long productId);

    @PutMapping("/{userId}/increaseqnty/{productId}")
    CartDTO increaseQuantity(@PathVariable("userId") Long userId,
                             @PathVariable("productId") Long productId,
                             @RequestParam("quantityToAdd") int qty);

    @PutMapping("/{userId}/decreaseqnty/{productId}")
    CartDTO decreaseQuantity(@PathVariable("userId") Long userId,
                             @PathVariable("productId") Long productId,
                             @RequestParam("quantityToRemove") int qty);

    @GetMapping("/{userId}/viewAllProducts")
    List<CartItemDTO> getCartItems(@PathVariable Long userId);

    @GetMapping("/{userId}/total-price")
    Double getTotalPrice(@PathVariable Long userId);

    @DeleteMapping("/{userId}/clearcart")
    String clearCart(@PathVariable Long userId);


}
