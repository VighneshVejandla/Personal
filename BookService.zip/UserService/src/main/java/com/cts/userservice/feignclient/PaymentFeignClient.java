package com.cts.userservice.feignclient;

import com.cts.userservice.dto.PaymentRequestDto;
import com.cts.userservice.dto.PaymentResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "PaymentService", path = "/payments")
public interface PaymentFeignClient {

    @PostMapping("/initiate")
    PaymentResponseDto initiatePayment(@RequestBody PaymentRequestDto paymentResponseDto);

    @PutMapping("/updatestatus/{paymentId}")
    String updatePaymentStatus(@PathVariable Long paymentId);

    @GetMapping("/viewstatus/{paymentId}")
    String viewPaymentStatus(@PathVariable Long paymentId);

    @PutMapping("/payments/{paymentId}/cancle")
    ResponseEntity<String> cancelPayment(@PathVariable Long paymentId);
}
