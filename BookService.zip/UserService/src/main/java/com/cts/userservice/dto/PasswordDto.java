package com.cts.userservice.dto;

import lombok.Data;

@Data
public class PasswordDto {
	
	private String password;
}
