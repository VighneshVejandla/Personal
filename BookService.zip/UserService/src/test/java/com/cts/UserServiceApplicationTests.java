package com.cts;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.modelmapper.ModelMapper;
import org.springframework.boot.test.context.SpringBootTest;

import com.cts.userservice.dto.UserDto;
import com.cts.userservice.entity.User;
import com.cts.userservice.exception.EmailAlreadyExistsException;
import com.cts.userservice.exception.ResourceNotFoundException;
import com.cts.userservice.repository.UserRepository;
import com.cts.userservice.service.UserServiceImplement;


@SpringBootTest
class UserServiceApplicationTests {
	
    @Mock
    private UserRepository userRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private UserServiceImplement userService; // Assuming your service implementation is named UserServiceImpl

    // Dummy data based on your input

    private User user; // For addUser, getUserById, updateUserById
    private User user1; // For viewAllUsers
    private User user2; // For viewAllUsers
    
    private UserDto userDto; // For addUser, getUserById, updateUserById
    private UserDto userDto1; // For viewAllUsers
    private UserDto userDto2; // For viewAllUsers
    
    private User userDeleted; // For viewAllUsers

    private UserDto userDtoDeleted; // For viewAllUsers

    private Long testUserId = 1L; // A common ID for individual user operations

    @BeforeEach
    void setUp() {
        // Data for addUser, getUserById, updateUserById, deleteUserById operations
        user = new User();
        user.setUserId(testUserId);
        user.setEmail("test@example.com");
        user.setPassword("password123");
        user.setRole("user");
        user.setCreatedDate(LocalDateTime.now().minusDays(5));
        user.setUpdatedDate(LocalDateTime.now().minusDays(5));
        user.setDeleted(false);
        
        userDto = new UserDto();
        userDto.setEmail("test@example.com");
        userDto.setPassword("password123");
        userDto.setUserId(testUserId); // Consistent ID for single-user operations

        // Data for viewAllUsers
        user1 = new User();
        user1.setUserId(1L); // Assuming this should be userId, not orderId
        user1.setEmail("user1@example.com");
        user1.setPassword("pass1");
        user1.setRole("user");
        user1.setCreatedDate(LocalDateTime.now());
        user1.setUpdatedDate(LocalDateTime.now());
        user1.setDeleted(false);

        userDto1 = new UserDto();
        userDto1.setUserId(1L);
        userDto1.setEmail("user1@example.com");
        userDto1.setPassword("pass1");

        // Non-deleted user 2
        user2 = new User();
        user2.setUserId(2L);
        user2.setEmail("user2@example.com");
        user2.setPassword("pass2");
        user2.setRole("admin"); // Different role for variety
        user2.setCreatedDate(LocalDateTime.now());
        user2.setUpdatedDate(LocalDateTime.now());
        user2.setDeleted(false);

        userDto2 = new UserDto();
        userDto2.setUserId(2L);
        userDto2.setEmail("user2@example.com");
        userDto2.setPassword("pass2");

        // Deleted user
        userDeleted = new User();
        userDeleted.setUserId(3L);
        userDeleted.setEmail("deleted@example.com");
        userDeleted.setPassword("pass3");
        userDeleted.setRole("user");
        userDeleted.setCreatedDate(LocalDateTime.now());
        userDeleted.setUpdatedDate(LocalDateTime.now());
        userDeleted.setDeleted(true);

        userDtoDeleted = new UserDto();
        userDtoDeleted.setUserId(3L);
        userDtoDeleted.setEmail("deleted@example.com");
        userDtoDeleted.setPassword("pass3");
    }
    
    @Test
    @DisplayName("Should add a new user successfully when email does not exist")
    void addUser_Success() {
        // Given
        when(userRepository.findByEmail(userDto.getEmail())).thenReturn(Optional.empty());
        when(modelMapper.map(userDto, User.class)).thenReturn(user); // Map DTO to Entity
        when(userRepository.save(any(User.class))).thenReturn(user); // Save the entity
        when(modelMapper.map(user, UserDto.class)).thenReturn(userDto); // Map saved Entity back to DTO

        // When
        UserDto result = userService.addUser(userDto);

        // Then
        assertNotNull(result);
        assertEquals(userDto.getEmail(), result.getEmail());
        assertEquals(userDto.getUserId(), result.getUserId());
        verify(userRepository, times(1)).findByEmail(userDto.getEmail());
        verify(modelMapper, times(1)).map(userDto, User.class);
        verify(userRepository, times(1)).save(any(User.class));

        // Verify that password, role, dates, and deleted flag are set correctly on the user object before saving
        verify(userRepository, times(1)).save(argThat(savedUser ->
                savedUser.getPassword().equals(userDto.getPassword()) &&
                        savedUser.getRole().equals("user") &&
                        savedUser.getCreatedDate() != null &&
                        savedUser.getUpdatedDate() != null &&
                        !savedUser.isDeleted()
        ));
        verify(modelMapper, times(1)).map(user, UserDto.class);
    }

    @Test
    @DisplayName("Should throw EmailAlreadyExistsException when email already exists")
    void addUser_EmailAlreadyExists() {
        // Given
        when(userRepository.findByEmail(userDto.getEmail())).thenReturn(Optional.of(user));

        // When / Then
        EmailAlreadyExistsException thrown = assertThrows(EmailAlreadyExistsException.class, () -> {
            userService.addUser(userDto);
        });

        assertEquals("Email Already Exists", thrown.getMessage());
        verify(userRepository, times(1)).findByEmail(userDto.getEmail());
        verify(modelMapper, never()).map(any(UserDto.class), any()); // No mapping should happen
        verify(userRepository, never()).save(any(User.class)); // No save should happen
    }

    @Test
    @DisplayName("Should return a list of all non-deleted users")
    void viewAllUsers_ReturnsNonDeletedUsers() {
        // Given
        List<User> allUsersFromRepo = Arrays.asList(user1, userDeleted, user2); // Note: userDeleted is included here to test filtering
        when(userRepository.findAll()).thenReturn(allUsersFromRepo);

        // Mock ModelMapper to map only the non-deleted users
        when(modelMapper.map(user1, UserDto.class)).thenReturn(userDto1);
        when(modelMapper.map(user2, UserDto.class)).thenReturn(userDto2);
        // We do NOT mock userDtoDeleted mapping, as it should not be mapped if correctly filtered

        // When
        List<UserDto> result = userService.viewAllUsers();

        // Then
        assertNotNull(result);
        assertEquals(2, result.size(), "Should contain only non-deleted users");
        assertTrue(result.contains(userDto1), "Result should contain user1");
        assertTrue(result.contains(userDto2), "Result should contain user2");
        assertFalse(result.contains(userDtoDeleted), "Result should not contain deleted user");

        // Verify that findAll was called once
        verify(userRepository, times(1)).findAll();

        // Verify ModelMapper was called for user1 and user2, but not for userDeleted
        verify(modelMapper, times(1)).map(user1, UserDto.class);
        verify(modelMapper, times(1)).map(user2, UserDto.class);
        verify(modelMapper, never()).map(userDeleted, UserDto.class); // Crucial: ensure deleted user is not mapped
    }

    @Test
    @DisplayName("Should return an empty list when no users exist in the repository")
    void viewAllUsers_ReturnsEmptyList_WhenNoUsers() {
        // Given
        when(userRepository.findAll()).thenReturn(Collections.emptyList());

        // When
        List<UserDto> result = userService.viewAllUsers();

        // Then
        assertNotNull(result);
        assertTrue(result.isEmpty(), "Result list should be empty");
        assertEquals(0, result.size());

        // Verify that findAll was called once
        verify(userRepository, times(1)).findAll();
        // Verify ModelMapper was never called
        verify(modelMapper, never()).map(any(User.class), any(UserDto.class));
    }

    @Test
    @DisplayName("Should return an empty list when all users are deleted")
    void viewAllUsers_ReturnsEmptyList_WhenAllUsersAreDeleted() {
        // Given
        List<User> allUsersFromRepo = Arrays.asList(userDeleted); // Only deleted users
        userDeleted.setDeleted(true); // Ensure it's marked as deleted
        when(userRepository.findAll()).thenReturn(allUsersFromRepo);

        // When
        List<UserDto> result = userService.viewAllUsers();

        // Then
        assertNotNull(result);
        assertTrue(result.isEmpty(), "Result list should be empty because all users are deleted");
        assertEquals(0, result.size());

        // Verify that findAll was called once
        verify(userRepository, times(1)).findAll();
        // Verify ModelMapper was never called for the deleted user as it should be filtered out
        verify(modelMapper, never()).map(any(User.class), any(UserDto.class));
    }

    @Test
    @DisplayName("Should return UserDto when user exists by ID")
    void getUserById_UserExists() {
        // Given
        when(userRepository.findById(testUserId)).thenReturn(Optional.of(user));
        when(modelMapper.map(user, UserDto.class)).thenReturn(userDto);

        // When
        UserDto result = userService.getUserById(testUserId);

        // Then
        assertNotNull(result);
        assertEquals(testUserId, result.getUserId());
        assertEquals(user.getEmail(), result.getEmail());
        assertEquals(user.getName(), result.getName());
        verify(userRepository, times(1)).findById(testUserId);
        verify(modelMapper, times(1)).map(user, UserDto.class);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException when user does not exist by ID for getUserById")
    void getUserById_UserDoesNotExist() {
        // Given
        when(userRepository.findById(testUserId)).thenReturn(Optional.empty());

        // When / Then
        ResourceNotFoundException thrown = assertThrows(ResourceNotFoundException.class, () -> {
            userService.getUserById(testUserId);
        });

        assertEquals("User not found with id : '" + testUserId + "'", thrown.getMessage());
        verify(userRepository, times(1)).findById(testUserId);
        verify(modelMapper, never()).map(any(User.class), any(UserDto.class)); // ModelMapper should not be called
    }
    
    @Test
    @DisplayName("Should update user successfully when user exists")
    void updateUserById_UserExists() {
        // Given
        UserDto updatedUserDto = new UserDto();
        updatedUserDto.setName("Jane Doe");
        updatedUserDto.setEmail("jane.doe@example.com");
        updatedUserDto.setPassword("newPassword456"); // New password
        updatedUserDto.setUserId(testUserId);

        User updatedUserEntity = new User();
        updatedUserEntity.setUserId(testUserId);
        updatedUserEntity.setName("Jane Doe");
        updatedUserEntity.setEmail("jane.doe@example.com");
        updatedUserEntity.setPassword("newPassword456");
        updatedUserEntity.setRole(user.getRole()); // Role typically doesn't change on update here
        updatedUserEntity.setCreatedDate(user.getCreatedDate());
        updatedUserEntity.setUpdatedDate(LocalDateTime.now()); // Will be updated by service
        updatedUserEntity.setDeleted(false);


        when(userRepository.findById(testUserId)).thenReturn(Optional.of(user)); // Return original user
        when(userRepository.save(any(User.class))).thenReturn(updatedUserEntity); // Save updated user
        when(modelMapper.map(updatedUserEntity, UserDto.class)).thenReturn(updatedUserDto); // Map saved entity back to DTO

        // When
        UserDto result = userService.updateUserById(testUserId, updatedUserDto);

        // Then
        assertNotNull(result);
        assertEquals(updatedUserDto.getName(), result.getName());
        assertEquals(updatedUserDto.getEmail(), result.getEmail());
        assertEquals(updatedUserDto.getPassword(), result.getPassword()); // Verify password update
        assertEquals(updatedUserDto.getUserId(), result.getUserId());

        verify(userRepository, times(1)).findById(testUserId);
        verify(userRepository, times(1)).save(argThat(u ->
                u.getUserId().equals(testUserId) &&
                        u.getName().equals("Jane Doe") &&
                        u.getEmail().equals("jane.doe@example.com") &&
                        u.getPassword().equals("newPassword456") &&
                        u.getUpdatedDate().isAfter(user.getUpdatedDate().minusMinutes(1)) // Verify updatedDate is set and is after original
        ));
        verify(modelMapper, times(1)).map(any(User.class), eq(UserDto.class));
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException when user does not exist for updateUserById")
    void updateUserById_UserDoesNotExist() {
        // Given
        UserDto updatedUserDto = new UserDto();
        updatedUserDto.setName("Non Existent");
        updatedUserDto.setEmail("non.existent@example.com");
        updatedUserDto.setUserId(testUserId);

        when(userRepository.findById(testUserId)).thenReturn(Optional.empty());

        // When / Then
        ResourceNotFoundException thrown = assertThrows(ResourceNotFoundException.class, () -> {
            userService.updateUserById(testUserId, updatedUserDto);
        });

        assertEquals("User not found with Id : '" + testUserId + "'", thrown.getMessage()); // Note: "Id" case in your code
        verify(userRepository, times(1)).findById(testUserId);
        verify(userRepository, never()).save(any(User.class));
        verify(modelMapper, never()).map(any(User.class), any(UserDto.class));
    }


    @Test
    @DisplayName("Should soft delete user successfully when user exists")
    void deleteUserById_UserExists() {
        // Given
        when(userRepository.findById(testUserId)).thenReturn(Optional.of(user)); // Return original user
        // Mock save to return the user, but we'll verify the 'deleted' flag on the argument
        when(userRepository.save(any(User.class))).thenReturn(user);

        // When
        userService.deleteUserById(testUserId);

        // Then
        verify(userRepository, times(1)).findById(testUserId);
        // Verify that save was called with the user and the 'deleted' flag set to true
        verify(userRepository, times(1)).save(argThat(u ->
                u.getUserId().equals(testUserId) && u.isDeleted() // Important: check if deleted flag is true
        ));
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException when user does not exist for soft delete")
    void deleteUserById_UserDoesNotExist() {
        // Given
        when(userRepository.findById(testUserId)).thenReturn(Optional.empty());

        // When / Then
        ResourceNotFoundException thrown = assertThrows(ResourceNotFoundException.class, () -> {
            userService.deleteUserById(testUserId);
        });

        assertEquals("User not found with Id : '" + testUserId + "'", thrown.getMessage());
        verify(userRepository, times(1)).findById(testUserId);
        verify(userRepository, never()).save(any(User.class)); // Save should not be called
    }

    @Test
    @DisplayName("Should permanently delete user successfully when user exists")
    void deleteUserByIdPermanent_UserExists() {
        // Given
        when(userRepository.findById(testUserId)).thenReturn(Optional.of(user));

        // When
        userService.deleteUserByIdPermenent(testUserId); // Note: typo in your method name "Permenent"

        // Then
        verify(userRepository, times(1)).findById(testUserId);
        verify(userRepository, times(1)).delete(user); // Verify delete method was called with the user
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException when user does not exist for permanent delete")
    void deleteUserByIdPermanent_UserDoesNotExist() {
        // Given
        when(userRepository.findById(testUserId)).thenReturn(Optional.empty());

        // When / Then
        ResourceNotFoundException thrown = assertThrows(ResourceNotFoundException.class, () -> {
            userService.deleteUserByIdPermenent(testUserId); // Note: typo in your method name "Permenent"
        });

        assertEquals("User not found with Id : '" + testUserId + "'", thrown.getMessage());
        verify(userRepository, times(1)).findById(testUserId);
        verify(userRepository, never()).delete(any(User.class)); // Delete should not be called
    }
	    
	    
	    

}
