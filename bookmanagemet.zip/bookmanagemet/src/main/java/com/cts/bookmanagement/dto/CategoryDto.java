package com.cts.bookmanagement.dto;

//import java.util.List;

import lombok.Data;

@Data
public class CategoryDto {
	private Long catId;
	private String catName;
//	private List<BookDto> books;
}
