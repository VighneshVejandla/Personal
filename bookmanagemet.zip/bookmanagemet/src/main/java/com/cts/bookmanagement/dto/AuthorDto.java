package com.cts.bookmanagement.dto;

import java.util.List;

import lombok.Data;

@Data
public class AuthorDto {
	private Long authId;
	private String authName;
//	private List<BookDto> books;
}
