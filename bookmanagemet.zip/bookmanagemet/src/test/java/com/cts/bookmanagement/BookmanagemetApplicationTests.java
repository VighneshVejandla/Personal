package com.cts.bookmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookmanagemetApplicationTests {

	@Test
	void contextLoads() {
	}

}
