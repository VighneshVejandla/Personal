package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.dto.ProfileDto;
import com.cts.service.IProfileService;


@RestController
@RequestMapping("/profile")
public class ProfileController {

    @Autowired
    private IProfileService profileService;

    @PostMapping("/create/{userId}")
    public ResponseEntity<ProfileDto> createProfile(@RequestBody ProfileDto profileDto, @PathVariable Long userId) {
        return new ResponseEntity<ProfileDto>(profileService.createProfile(profileDto, userId), HttpStatus.OK);
    }

    @GetMapping("/view/{userId}")
    public ResponseEntity<ProfileDto> getProfile(@PathVariable Long userId) {
        return new ResponseEntity<ProfileDto>(profileService.getProfileByUserId(userId), HttpStatus.OK);
    }

    @PutMapping("/update/{userId}")
    public ResponseEntity<ProfileDto> updateProfile(@PathVariable Long userId, @RequestBody ProfileDto profileDto) {
        return new ResponseEntity<ProfileDto>(profileService.updateProfile(userId, profileDto), HttpStatus.OK);
    }

    @DeleteMapping("/delete/{userId}")
    public ResponseEntity<String> deleteProfile(@PathVariable Long userId) {
        profileService.deleteProfileByUserId(userId);
        return new ResponseEntity<String >("Profile deleted successfully.", HttpStatus.OK);
    }

    @DeleteMapping("/harddelete/{userId}")
    public ResponseEntity<String> hardDeleteProfile(@PathVariable Long userId) {
        profileService.hardDeleteProfile(userId);
        return new ResponseEntity<String >("Profile deleted From the DataBase.", HttpStatus.OK);
    }

    @PutMapping("/recoverprofile/{userId}")
    public ResponseEntity<String> recoverProfile(@PathVariable Long userId) {
        profileService.recoverProfile(userId);
        return new ResponseEntity<String >("Profile Recovered successfully.", HttpStatus.OK);
    }
}

