package com.cts.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import com.cts.dto.ReviewDTO;
import com.cts.exception.ProfileExceptions;
import com.cts.exception.ResourceNotFoundException;
import com.cts.exception.ResoureAlreadyExistException;
import com.cts.exception.UserNotFoundByIdException;
import com.cts.feignclient.ReviewClient;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dto.ProfileDto;
import com.cts.entity.Profile;
import com.cts.entity.User;
import com.cts.repository.ProfileRepository;
import com.cts.repository.UserRepository;

@Service
public class ProfileServiceImplement implements IProfileService {

    @Autowired
    ProfileRepository profileRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    ReviewClient reviewClient;

    private ProfileDto mapToDto(Profile profile) {
        return modelMapper.map(profile, ProfileDto.class);
    }

    private Profile mapToEntity(ProfileDto profileDto) {
        return modelMapper.map(profileDto, Profile.class);
    }

    @Override
    public ProfileDto createProfile(ProfileDto profileDto, Long userId) {

        User user = userRepository.findById(userId)
                .filter(u -> !u.isDeleted())
                .orElseThrow(() -> new UserNotFoundByIdException("User", "id", userId));

//        Optional<Profile> existingProfile = Optional.ofNullable(profileRepository.findByUserUserId(userId));
        if (profileRepository.findByUserUserId(userId) != null) {
            throw new ProfileExceptions.ProfileAlreadyExistsException("Profile already exists for user ID: " + userId);
        }

        Profile profile = mapToEntity(profileDto);

        profile.setCreatedAt(LocalDateTime.now());
        profile.setUpdatedAt(LocalDateTime.now());
        profile.setUser(user);

        Profile savedProfile = profileRepository.save(profile);
        return mapToDto(savedProfile);
    }

    @Override
    public ProfileDto getProfileByUserId(Long userId) {

        User user = userRepository.findById(userId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("User", "UserId", userId));

        if(user.isDeleted()){
            throw new ResourceNotFoundException("User", "UserId", userId);
        }

        return Optional.ofNullable(profileRepository.findByUserUserId(userId))
                .map(profile -> {
                    if(profile.isDeleted()){
                        throw new ResourceNotFoundException("Profile", "UserId", userId + " not Found");
                    }
                    return mapToDto(profile);
                })
                .orElseThrow(() -> new ProfileExceptions.ProfileIsInActiveException("Profile"+userId+"is Already is In active"));
    }

    @Override
    public ProfileDto updateProfile(Long userId, ProfileDto profileDto) {

        return Optional.ofNullable(profileRepository.findByUserUserId(userId))
                        .map(profile -> {
                            profile.setBio(profileDto.getBio());
                            profile.setPhoneNumber(profileDto.getPhoneNumber());
                            profile.setAddress(profileDto.getAddress());
                            profile.setUpdatedAt(LocalDateTime.now());
                            return profileRepository.save(profile);
                        }).map(this::mapToDto)
                .orElseThrow(() -> new ResourceNotFoundException("Profile", "UserId", userId));

    }

    @Override
    public void deleteProfileByUserId(Long userId) {

        Optional.ofNullable((profileRepository.findByUserUserId(userId)))
                .ifPresentOrElse(
                        profile -> {
                            if(profile.isDeleted() == false) {
                                profile.setDeleted(true);
                                profileRepository.save(profile);
                            }else{
                                throw new ResourceNotFoundException("profile", "userId", userId );
                            }
                        },
                        ()->{
                            throw new ResourceNotFoundException("User", "userId", userId);
                        }
                );
    }

    @Override
    public void recoverProfile(Long userId) {

        User user = userRepository.findById(userId)
                .filter(u-> !u.isDeleted())
                .orElseThrow(() -> new ResourceNotFoundException("user", "UserId", userId));

        Profile profile = Optional.ofNullable(profileRepository.findByUserUserId(userId))
                .filter(Profile::isDeleted)
                .orElseThrow(() -> new ProfileExceptions.ProfileIsInActiveException("Profile with userId "+userId+" is in active"));

        profile.setDeleted(false);
        profileRepository.save(profile);
    }


    public void hardDeleteProfile(Long userId) {
        Profile profile = Optional.ofNullable(profileRepository.findByUserUserId(userId))
                .orElseThrow(() -> new ResourceNotFoundException("Profile", "userId", userId));

        if (profile.getUser() == null || profile.getUser().getUserId() == null) {
            throw new ResourceNotFoundException("User", "userId", userId);
        }

        if (profile.isDeleted()) {
            User user = profile.getUser();
            user.setProfile(null);

            List<ReviewDTO> reviews = reviewClient.getReviewsByUserId(userId);
            reviews.forEach(review -> reviewClient.hardDeleteReview(review.getReviewId()));

            profileRepository.delete(profile);
        } else {
            throw new ResourceNotFoundException("Profile must be soft deleted before hard deleting", "userId", userId);
        }
    }

    public void deleteAllReviewsForUser(Long userId){
        List<ReviewDTO> reviews = reviewClient.getReviewsByUserId(userId);
        reviews.forEach(review -> reviewClient.hardDeleteReview(review.getReviewId()));

    }


}