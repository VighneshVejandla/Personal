package com.cts.service;

import java.util.List;

import com.cts.dto.PasswordDto;
import com.cts.dto.UserDto;


public interface IUserService {
//	User addUser(User user);
//	List<User> viewAllUsers();
//	User getUserById(Long userId);
//	User updateUserById(Long userId, User user);
//	void deleteUserById(long userId);
	
	
	UserDto addUser(UserDto user);
	List<UserDto> viewAllUsers();
	UserDto getUserById(Long userId);
	UserDto updateUserById(Long userId, UserDto userDto);
	void deleteUserById(long userId);
	void deleteUserByIdPermenent(long userId);
	void recoverTheAccountByEmail(String email);
	
	void changePassword(Long userId, PasswordDto userDto);

}
