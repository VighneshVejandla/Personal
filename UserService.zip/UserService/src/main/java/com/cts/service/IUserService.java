package com.cts.service;

import java.util.List;

import com.cts.dto.PasswordDto;
import com.cts.dto.UserDto;
import com.cts.entity.User;


public interface IUserService {

	UserDto addUser(UserDto user);
	List<UserDto> viewAllUsers();
	UserDto getUserById(Long userId);
	UserDto updateUserById(Long userId, UserDto userDto);
	void deleteUserById(long userId);
	void deleteUserByIdPermenent(long userId);
	void recoverTheAccountByEmail(String email);
	void recoverTheAccountByUserId(Long userId);
	void changePassword(Long userId, PasswordDto userDto);

	List<User> getAllDeletedUsers();

}
